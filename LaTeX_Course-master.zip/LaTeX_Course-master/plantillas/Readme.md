# Licencia de uso

Todas las plantillas aquí disponibles están disponibles mediante una licencia LPPL y otra compatible GPL (Software Libre), es decir, puede utilizarlas, modificarlas y compartirlas siempre que respete los términos de la licencia bajo la cual han sido publicadas inicialmente.

Algunas de estas plantillas corresponden a la traducción al idioma Español de plantillas originalmente publicadas en idioma Inglés, no nos hacemos responsables de impresiciones en los términos de la traducción. 

## Índice de plantillas en español disponibles en Overleaf
* [Plantilla para cartas][1]

[1]: https://www.overleaf.com/latex/templates/plantilla-para-cartas/myxtzxtsmsdy
